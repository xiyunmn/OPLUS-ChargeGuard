/* SPDX-License-Identifier: GPL-2.0-only */


#ifndef __ASM_MEM_RELINQUISH_H
#define __ASM_MEM_RELINQUISH_H

struct page;

void page_relinquish(struct page *page);
void post_page_relinquish_tlb_inv(void);

#endif	
